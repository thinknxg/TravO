import os
import re
import frappe
from frappe import _
from frappe.utils import flt, get_url, format_datetime, formatdate
from urllib.parse import quote


def _settings():
    return frappe.get_cached_doc("Rental Tour Settings")


# ---------------------------------------------------------------------------
# Recipient resolution
# ---------------------------------------------------------------------------
def _recipient_email(doc):
    return doc.get("contact_email") or frappe.db.get_value("Customer", doc.customer, "email_id")


def _recipient_phone(doc):
    return doc.get("contact_phone") or frappe.db.get_value("Customer", doc.customer, "mobile_no")


def _digits(phone):
    if not phone:
        return ""
    return re.sub(r"\D", "", str(phone).lstrip("+"))


# ---------------------------------------------------------------------------
# Message content
# ---------------------------------------------------------------------------
def _context(doc):
    s = _settings()
    cur = s.default_currency or "OMR"
    company = s.company or frappe.defaults.get_global_default("company") or _("Our Company")
    if doc.doctype == "Car Rental Booking":
        summary = _("{0} · {1} → {2}").format(
            doc.vehicle,
            format_datetime(doc.pickup_datetime, "dd MMM, HH:mm"),
            format_datetime(doc.dropoff_datetime, "dd MMM, HH:mm"),
        )
    else:
        depart = ", " + _("departing {0}").format(formatdate(doc.departure_date)) if doc.get("departure_date") else ""
        summary = _("{0}{1}").format(doc.tour_package, depart)
    return {
        "company": company, "cur": cur, "summary": summary,
        "number": doc.get("booking_number") or doc.name,
        "name": doc.customer_name or doc.customer,
        "total": flt(doc.grand_total), "outstanding": flt(doc.outstanding_amount),
    }


def _message_text(doc, confirmed=True):
    c = _context(doc)
    head = _("Your booking is confirmed.") if confirmed else _("We've received your booking request.")
    return _(
        "Hello {name},\n\n{head}\n"
        "Booking No: {number}\n{summary}\n"
        "Total: {total:.2f} {cur}\nBalance due: {outstanding:.2f} {cur}\n\n"
        "Thank you for choosing {company}."
    ).format(head=head, **c)


# ---------------------------------------------------------------------------
# WhatsApp
# ---------------------------------------------------------------------------
def get_whatsapp_link(doc):
    """Click-to-chat URL with a pre-filled confirmation message."""
    phone = _digits(_recipient_phone(doc))
    text = _message_text(doc)
    return "https://wa.me/{0}?text={1}".format(phone, quote(text))


def _send_meta_whatsapp(s, phone, text, doc):
    import requests
    token = s.get_password("whatsapp_access_token")
    url = "https://graph.facebook.com/v19.0/{0}/messages".format(s.whatsapp_phone_number_id)
    payload = {"messaging_product": "whatsapp", "to": phone, "type": "text", "text": {"body": text}}
    headers = {"Authorization": "Bearer {0}".format(token), "Content-Type": "application/json"}
    resp = requests.post(url, json=payload, headers=headers, timeout=15)
    if resp.status_code >= 300:
        frappe.log_error(resp.text, "Meta WhatsApp send failed")
        return False
    doc.add_comment("Info", _("WhatsApp confirmation sent to {0}").format(phone))
    return True


def _send_whatsapp(doc):
    s = _settings()
    phone = _digits(_recipient_phone(doc))
    if not phone:
        return None
    text = _message_text(doc)
    provider = s.get("whatsapp_provider") or "Click to Chat"
    if provider == "Meta Cloud API" and s.get("whatsapp_phone_number_id") and s.get_password("whatsapp_access_token"):
        _send_meta_whatsapp(s, phone, text, doc)
        return None
    # Click-to-chat: we can't auto-send, so record the link on the timeline for staff.
    link = get_whatsapp_link(doc)
    doc.add_comment("Info", _("WhatsApp click-to-chat link generated."))
    return link


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------
def _send_email(doc, confirmed=True):
    email = _recipient_email(doc)
    if not email:
        return False
    s = _settings()
    c = _context(doc)
    subject = _("Booking {0} — {1}").format(c["number"], _("Confirmed") if confirmed else _("Received"))
    template_path = os.path.join(
        frappe.get_app_path("rental_tour_booking"), "templates", "emails", "booking_confirmation.html"
    )
    with open(template_path, "r") as fh:
        template = fh.read()
    html = frappe.render_template(
        template,
        {"c": c, "doc": doc, "confirmed": confirmed, "portal_url": get_url("/my-bookings")},
    )
    attachments = []
    if confirmed:
        pf = "Rental Agreement" if doc.doctype == "Car Rental Booking" else "Tour Voucher"
        try:
            attachments = [frappe.attach_print(doc.doctype, doc.name, print_format=pf)]
        except Exception:
            frappe.log_error(frappe.get_traceback(), "Booking PDF attach failed")
    frappe.sendmail(
        recipients=[email], subject=subject, message=html, attachments=attachments,
        sender=s.get("notification_sender") or None,
        reference_doctype=doc.doctype, reference_name=doc.name,
    )
    return True


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------
def send_booking_confirmation(doc, method=None):
    """on_submit hook: full confirmation (email w/ PDF + WhatsApp)."""
    s = _settings()
    if s.get("send_confirmation_email"):
        try:
            _send_email(doc, confirmed=True)
        except Exception:
            frappe.log_error(frappe.get_traceback(), "Booking confirmation email failed")
    if s.get("send_whatsapp"):
        try:
            _send_whatsapp(doc)
        except Exception:
            frappe.log_error(frappe.get_traceback(), "Booking confirmation WhatsApp failed")


def maybe_acknowledge(doc):
    """Called right after a portal-created Draft booking: light acknowledgement email."""
    s = _settings()
    if not s.get("send_confirmation_email"):
        return
    try:
        _send_email(doc, confirmed=False)
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Booking acknowledgement email failed")


@frappe.whitelist()
def resend_confirmation(doctype, name):
    doc = frappe.get_doc(doctype, name)
    sent_email = _send_email(doc, confirmed=True)
    link = _send_whatsapp(doc)
    frappe.msgprint(_("Confirmation {0}.").format(_("sent") if sent_email else _("could not be emailed (no address)")))
    return {"emailed": bool(sent_email), "whatsapp_link": link or get_whatsapp_link(doc)}


@frappe.whitelist()
def whatsapp_link(doctype, name):
    return get_whatsapp_link(frappe.get_doc(doctype, name))
