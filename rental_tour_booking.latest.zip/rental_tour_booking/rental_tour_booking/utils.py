import frappe
import re
from frappe.utils import flt, date_diff, getdate


def generate_booking_number():
    """Short, human-friendly, globally-unique booking reference: RT-XXXX-XXXX."""
    for _ in range(25):
        raw = re.sub(r"[^A-Z0-9]", "", frappe.generate_hash(length=10).upper())
        raw = (raw + "ABCDEFGH")[:8]
        code = "RT-{0}-{1}".format(raw[:4], raw[4:8])
        clash = frappe.db.exists("Car Rental Booking", {"booking_number": code}) or \
            frappe.db.exists("Tour Package Booking", {"booking_number": code})
        if not clash:
            return code
    return "RT-" + re.sub(r"[^A-Z0-9]", "", frappe.generate_hash(length=10).upper())[:8]


def get_settings():
    return frappe.get_cached_doc("Rental Tour Settings")


def get_default_vat_rate():
    try:
        rate = flt(get_settings().vat_rate)
    except Exception:
        rate = 0.0
    return rate


def get_default_terms():
    try:
        return get_settings().default_terms
    except Exception:
        return None


def rental_day_count(pickup, dropoff):
    """Inclusive-ish day count: a rental of <24h counts as 1 day, then rounds up."""
    if not pickup or not dropoff:
        return 0
    diff = date_diff(getdate(dropoff), getdate(pickup))
    return max(1, int(diff) if diff else 1)
